const csv = require('csv-parser')
const fs = require('fs')

const results = []

// reading file from csv 
fs.createReadStream('input_countries.csv')
  .pipe(csv())
  .on('data', (data) => results.push(data))
  .on('end', () => {
    // console.log(results);
    const canada = 'canada.txt'
    const usa = 'usa.txt'
    // writing data to canada.txt
    try {   
        // checking if canada.txt exits
        if(fs.existsSync(canada)) {
            fs.unlinkSync(canada)
        }
        if(fs.existsSync(usa)) {
            fs.unlinkSync(usa)
        }
        const canadaData = results.filter((result) => result.country.toLowerCase() === 'canada')
        const usaData = results.filter((result) => result.country.toLowerCase() === 'united states')
        fs.appendFileSync(canada, 'country,year,population\n')
        fs.appendFileSync(usa, 'country,year,population\n')
        canadaData.forEach((data) => {
            fs.appendFileSync(canada, `${data.country},${data.year},${data.population}\n`)
        })
        usaData.forEach((data) => {
            fs.appendFileSync(usa, `${data.country},${data.year},${data.population}\n`)
        })
    }catch(err) {
        console.log(err)
    }
  });